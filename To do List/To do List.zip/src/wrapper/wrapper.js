export const OPEN = "open"
export const INPROGRESS = "inprogress"
export const COMPLETED = "completed"

export const statuses = [
    {name: "open"},
    {name: "inprogress"},
    {name: "completed"},
]
