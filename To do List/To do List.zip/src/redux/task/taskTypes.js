export const ADD_NEW_TASK = "ADD_NEW_TASK"
export const EDIT_TASK = "EDIT_TASK"
export const DELETE_TASK = "DELETE_TASK"